</>

let currentImage = 0;
const images = document.querySelectorAll(".slider-width");

function showImage() {
    images.forEach(image => image.style.display = "none");

    currentImage++;

    if (currentImage > images.length) {
        currentImage = 1;
    }

    images[currentImage - 1].style.display = "block";

    setTimeout(showImage, 3000);
}

showImage();
